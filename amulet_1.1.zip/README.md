# YouAreTheAmulet
7DRL 2022 entry

This game requires Pygame 2.1.2 and Python 3.9, as that was what I used when I developed it. It's possible that earlier versions of Python and Pygame might work.

* Clone the repo
* `python3 main.py`

No other libraries should be needed.
