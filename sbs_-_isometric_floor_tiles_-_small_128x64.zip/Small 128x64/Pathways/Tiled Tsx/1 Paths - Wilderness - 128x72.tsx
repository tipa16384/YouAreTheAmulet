<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="1 Wilderness - 128x72" tilewidth="128" tileheight="72" tilecount="12" columns="4">
 <image source="D:/John's Graphic Packs/John's Isometric Tiles/Pathways/1 Wilderness - 128x72.png" trans="000000" width="512" height="216"/>
</tileset>
