<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="1 Floor - Wood 128x64" tilewidth="128" tileheight="64" tilecount="9" columns="3">
 <image source="D:/John's Graphic Packs/John's Isometric Tiles/Interior/1 Floor - Wood 128x64.png" trans="000000" width="384" height="192"/>
</tileset>
